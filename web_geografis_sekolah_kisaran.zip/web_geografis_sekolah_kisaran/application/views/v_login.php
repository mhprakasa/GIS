<?php include("header.php"); ?>



<div class="container">    
  <div class="row">
    <div class="col-sm-4 col-md-offset-4">
      <div class="panel panel-primary">
        <div class="panel-heading">Login</div>
        <div class="panel-body">

      <?php 
        //notifikasi error
      echo validation_errors('<div class="alert alert-warning">','</div>');
      //notifikasi

      if ($this->session->flashdata('warning')) {
        echo '<div class="alert alert-warning">';
        echo $this->session->flashdata('warning');
        echo '</div>';
        # code...
      }
      //notifikasi sukses
      if ($this->session->flashdata('sukses')) {
          echo '<div class="alert alert-success">';
        echo $this->session->flashdata('sukses');
        echo '</div>';
        # code...
      }
      //form open
      echo form_open(base_url('login'),'class="form-horizontal" entype="multipart/formdata"');
      ?>
        <div class="col-sm-12">
          <div class="form-group input-group">
              <span class="input-group-addon"><i class="fa fa-user"></i></span>
              <input type="text" name="username" class="form-control" placeholder="Username" required>
        </div>
        </div>

        <div class="col-sm-12">
          <div class="form-group input-group">
              <span class="input-group-addon"><i class="fa fa-lock"></i></span>
              <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>
        </div>
        <div class="col-sm-12">
          <div class="form-group input-group">
              <button type="submit" class="btn btn-primary">Login</button>
        </div>
        </div>


      <?php echo form_close();  ?>
        </div>
        <div class="panel-footer"></div>
      </div>
    </div>
  </div>
</div>




<?php include("footer.php"); ?>