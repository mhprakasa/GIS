<?php include("header_admin.php"); ?>



<div class="container">    
  <div class="row">
    <div class="col-sm-7">
      <div class="panel panel-primary">
        <div class="panel-heading">Lokasi Sekolah</div>
        <div class="panel-body">
          
          <?php echo $map['html']; ?>

        </div>
        <div class="panel-footer"></div>
      </div>
    </div>

    <div class="col-sm-5">
      <div class="panel panel-primary">
        <div class="panel-heading">Input Data Sekolah</div>
        <div class="panel-body">
          
          <?php 
        //notifikasi error
      echo validation_errors('<div class="alert alert-warning">','</div>');
      //notifikasi sukses
      if ($this->session->flashdata('sukses')) {
          echo '<div class="alert alert-success">';
        echo $this->session->flashdata('sukses');
        echo '</div>';
        # code...
      }
      //form open
      echo form_open(base_url('admin/update/'.$sekolah->id_sekolah),'class="form-horizontal" entype="multipart/formdata"');
      ?>

      <form class="form-horizontal">
        <div class="form-group">
          <label class="col-sm-4 control-label">Nama Sekolah</label>
          <div class="col-sm-8">
            <input type="text" name="nama_sekolah" class="form-control" placeholder="Nama Sekolah" value="<?php echo $sekolah->nama_sekolah; ?>" required>
          </div>
        </div>

        <div class="form-group">
          <label class="col-sm-4 control-label">Alamat</label>
          <div class="col-sm-8">
            <input type="text" name="alamat" class="form-control" placeholder="alamat" value="<?php echo $sekolah->alamat; ?>" required>
          </div>
        </div>

        <div class="form-group">
          <label class="col-sm-4 control-label">No Telpon</label>
          <div class="col-sm-8">
            <input type="text" name="no_telpon" class="form-control" placeholder="No Telpon" value="<?php echo $sekolah->no_telpon; ?>" required>
          </div>
        </div> 

         <div class="form-group">
          <label class="col-sm-4 control-label">Latitude</label>
          <div class="col-sm-8">
            <input type="text" name="latitude" class="form-control" placeholder="Latitude" value="<?php echo $sekolah->latitude; ?>" required>
          </div>
        </div>

        <div class="form-group">
          <label class="col-sm-4 control-label">Longitude</label>
          <div class="col-sm-8">
            <input type="text" name="longitude" class="form-control" placeholder="Longitude" value="<?php echo $sekolah->longitude; ?>" required>
          </div>
        </div>

        <div class="form-group">
          <label class="col-sm-4 control-label">Deskripsi</label>
          <div class="col-sm-8">
            <input type="text" name="deskripsi" class="form-control" value="<?php echo $sekolah->deskripsi; ?>" required>
          </div>
        </div>

        <div class="form-group">
          <label class="col-sm-4 control-label"></label>
          <div class="col-sm-8">
            <button class="btn btn-primary" type="submit">Update</button>
            <button class="btn btn-success" type="reset">Reset</button> 
          </div>
        </div>


      </form>





      <?php echo form_close();  ?>


        </div>
        <div class="panel-footer"></div>
      </div>
    </div>

  </div>
</div>




<?php include("footer.php"); ?>