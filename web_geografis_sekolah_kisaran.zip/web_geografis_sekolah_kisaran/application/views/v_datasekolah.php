<?php include("header_admin.php"); ?>

<div class="container">    
  <div class="row">
    <div class="col-sm-12">
      <?php 
          //notifikasi sukses
           if ($this->session->flashdata('sukses')) {
          echo '<div class="alert alert-success">';
          echo $this->session->flashdata('sukses');
          echo '</div>';
            }
           ?>
      <div class="panel panel-primary">
        <div class="panel-heading">Data Sekolah Kota Kisaran</div>
        <div class="panel-body">

          <div class="table-responsive">
            <table class=" table table-striped table-bordered table-hover" id="tabel">
              <thead>
                <tr>
                  <th style="width : 50px">No</th>
                  <th>Nama Sekolah</th>
                  <th>Alamat Sekolah</th>
                  <th>No Telpon</th>
                  <th>Latitude</th>
                  <th>Longitude</th>
                  <th>Deskripsi</th>
                  <th style="width : 70px">Action</th>
                </tr>
              </thead>
              <?php $no=1 ; foreach($sekolah as $sekolah) { ?>
                <tr>
                  <td><?php echo $no++; ?>.</td>
                  <td><?php echo $sekolah->nama_sekolah; ?></td>
                  <td><?php echo $sekolah->alamat; ?></td>
                  <td><?php echo $sekolah->no_telpon; ?></td>
                  <td><?php echo $sekolah->latitude; ?></td>
                  <td><?php echo $sekolah->longitude; ?></td>
                  <td><?php echo $sekolah->deskripsi; ?></td>
                  <td>
                    <a href="<?php echo base_url('admin/update/'.$sekolah->id_sekolah) ?>" class="btn btn-warning btn-sm" type="button"><i class="fa fa-pencil"></i></a>
                    <a href="<?php echo base_url('admin/delete/'.$sekolah->id_sekolah) ?>" type="button" class="btn  btn-danger btn-sm" onclick="return confirm('Yakin Ingin Menghapus Data ini.?')" type="button" class="btn  btn-danger btn-sm" onclick="return confirm('Yakin Ingin Menghapus Data ini.?')"><i class="fa fa-trash"></i></a>
                  </td>
                </tr>
              <?php } ?>
            </table>
            
          </div>


        </div>
        <div class="panel-footer"></div>
      </div>
    </div>
  </div>
</div>


<?php include("footer.php"); ?>