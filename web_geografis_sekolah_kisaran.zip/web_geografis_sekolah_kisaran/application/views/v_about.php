<?php include("header.php"); ?>

<div class="container">    
  <div class="row">
    <div class="col-sm-12">
      <div class="panel panel-primary">
        <div class="panel-heading">Pemetaan Lokasi Sekolah</div>
        <div class="panel-body">

          
          <h3>Nama : MUHAMMAD HAJIPTO PRAKASA </h3>
          <h3>Kelas : SI-7N </h3>
         

        </div>
		<div class="panel-body">

      
          <h3>Nama : PRIYANTO </h3>
          <h3>Kelas : SI-7N </h3>
         

        </div>
		<div class="panel-body">

          
          <h3>Nama :TIARA DWI TANTI </h3>
          <h3>Kelas : SI-7N </h3>
         

        </div>
        <div class="panel-footer"></div>
      </div>
    </div>
  </div>
</div>


<?php include("footer.php"); ?>